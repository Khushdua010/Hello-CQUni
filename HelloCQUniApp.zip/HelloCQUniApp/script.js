
function changeGreeting() {
    document.getElementById('greeting').textContent = 'Hello, Central Queensland University!';
}
